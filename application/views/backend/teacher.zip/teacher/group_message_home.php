<div class="full-chat-middle">
    <div class="">
        <div class="">
			<div class="centeredu">
				<img src="<?php echo base_url();?>uploads/mensajeseducaby.svg" style="margin-top:-35px; width:100%;">	<br>

				<a href="<?php echo base_url();?>teacher/group/create_message_group/" class="msjsbtn mt"><span><?php echo get_phrase('create_group');?></span><i class="os-icon picons-thin-icon-thin-0001_compose_write_pencil_new"></i></a>			   
        	</div>                        
      	</div>
	</div>
</div>