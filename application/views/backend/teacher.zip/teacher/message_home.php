<div class="full-chat-middle">
    <div class="">
        <div class="">
			<div class="centeredu">
				<img src="<?php echo base_url();?>uploads/mensajeseducaby.svg" style="margin-top:-35px; width:100%;">	<br>			   
			    <a href="<?php echo base_url();?>teacher/message/message_new/" class="msjsbtn mt"><span><?php echo get_phrase('create_message');?></span><i class="picons-thin-icon-thin-0317_send_post_paper_plane"></i></a>				   
        	</div>                        
      	</div>
	</div>
</div>